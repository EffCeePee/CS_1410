// File Prologue
// Name: Franklin Colton Parry
// Section: 01
// Project: Lab 02
// Date:  5/11/2013


// I declare that the following source code was written by me, or provided
// by the instructor for this project. I understand that copying
// source code from any other source constitutes cheating, and that I will
// receive a zero grade on this project if I am found in violation of
// this policy.
// __________________________________________________________________________


#include <iostream>
#include <string>
#include <iomanip>
#include <vector>
using namespace std;

// declare constants
const int SIZE = 5;

int main( )
{

	cout << "\nFranklin Colton Parry";
	cout << "\nThis program will add together 5 numbers";
	// declare variables 
	// a vector of doubles
	vector<double> newVector;
	double sumArray[SIZE];
	double vnumber = 0;
	double anumber = 0;
	int count = 0;
	
	// a loop to prompt the user to put in numbers 
	do 
	{
		cout << "\nPlease enter in a number with a decimal, or press zero to exit: ";
		// assign the number to the number variable
		cin >> vnumber;
		// if number is greater than 0 then put it in the vector using push back method
		if (vnumber != 0)
			newVector.push_back(vnumber);
		// increment counter
		count++;
		// end loop if it is 0 or the user has entered in 5 numbers

	}while (vnumber != 0 && count != 5);


	// begin another loop to assign the numbers in the vector to an array
	for (int i = 0; i < SIZE; i++)
	{
		// assign vector to array
		sumArray[i] =  newVector[i];
	
	}

	// start a loop to add the array
	for (int i = 0; i < SIZE; i++)
	{
		// assign vector to array
		anumber += sumArray[i];
	}

	// write the numbers with formatting
	cout.setf(ios::fixed);
    cout.precision(2);
	cout << "\nthe sum of the numbers is: " << anumber << "\n" ;


system("pause");
	return 0;
} // end main